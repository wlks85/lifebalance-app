import React from 'react';

export interface AuxProps {
  children?: React.ReactNode;
}
