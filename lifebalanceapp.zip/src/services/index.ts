import userService from './UserService';
import receiptService from './ReceiptService';
export const UserService = userService;
export const ReceiptService = receiptService;
