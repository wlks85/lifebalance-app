import {SvgProps} from 'react-native-svg';

export interface SvgProperty extends SvgProps {
  size?: number;
  name?: string;
}
