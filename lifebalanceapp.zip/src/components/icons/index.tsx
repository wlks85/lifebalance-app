import FaIcons from './fa-icons';
export const Icons = FaIcons;
